# Advanced Remote Controller — Multi-device Relay Starter

This ZIP contains:
- `web/`: your edited web interface and a relay URL configuration template.
- `relay/`: a Node.js WebSocket relay starter with companion authentication, ID routing, explicit pairing approval, and trust tokens.
- `companion-examples/`: protocol notes for building a companion for each operating system.

## Important: what this ZIP does and does not do

The relay is source code included in the project. It is **not already hosted** and does not run inside the HTML page. You must deploy it to a server with HTTPS/WSS.

This is a relay foundation, not a complete remote-control product. It does not itself implement mouse/keyboard/system-control APIs for Windows, Android, iOS, or iPadOS. Each platform needs its own companion app, and each OS restricts what that app can control. iOS/iPadOS do not permit a general-purpose app to take unrestricted control of another device.

The browser UI currently speaks an earlier `connect_by_id` protocol. The relay accepts that message and emits `pairing_required`, but the current UI does not yet implement the target-side approval screen. A companion must receive `pairing_request`, display it to the device owner, and send `pairing_decision`. Do not bypass this approval.

## Run locally (development only)

Requirements: Node.js 20+.

1. Open a terminal in `relay/`.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Copy `.env.example` to `.env`.
4. Set `COMPANION_SHARED_SECRET` to a long random secret (at least 32 characters).
5. Start:
   ```bash
   npm start
   ```
6. Health check: `http://localhost:8080/health`

The local development server uses `ws://` and is **not suitable for public internet use**.

## Deploy securely

Deploy `relay/` to a VPS or hosting platform that supports long-running Node.js WebSocket processes. Put it behind a TLS reverse proxy (for example Caddy or Nginx) and expose only `wss://`. Configure the proxy to forward WebSocket upgrades to port 8080. Do not expose the plain WebSocket port publicly.

After deployment:
1. Copy `web/config.example.js` to `web/config.js`.
2. Replace `wss://YOUR-RELAY-DOMAIN` with your real deployed WSS URL.
3. Publish the `web/` folder (for example, on GitHub Pages).
4. Build and install the companion app for each target platform.

## Relay protocol summary

### Companion registration
A companion opens a WebSocket and sends:
```json
{"type":"register_device","device_id":"12345678","platform":"windows","secret":"YOUR_SHARED_SECRET"}
```
The server responds with `registered`.

### Browser connection request
The web UI sends `connect_by_id` with `device_id` and `target_id` (also `pc_id` for backward compatibility). The relay forwards `pairing_request` to the target companion.

### Explicit approval
The target companion must show the request to its owner. On approval:
```json
{"type":"pairing_decision","client_id":"87654321","approve":true}
```
On denial use `approve:false`. The relay then issues a revocable trust token to the client. A production companion should offer a local “revoke trusted devices” action.

### Data relay
After approval, client messages are forwarded to the companion as:
```json
{"type":"relay","client_id":"87654321","payload":{"type":"..."}}
```
The companion returns:
```json
{"type":"device_response","client_id":"87654321","payload":{"type":"system_info","data":{}}}
```

## Production hardening required before real use

- Replace in-memory device/session/token maps with a durable store such as Redis.
- Use per-device credentials/certificates rather than one shared companion secret.
- Add token expiry, rotation, revocation, and account/device ownership.
- Add message schemas and per-command authorization on every companion.
- Add abuse controls, audit logs, backups, monitoring, and denial-of-service protection.
- Ensure end-to-end encryption if relay operators must not read command payloads.
- Never expose dangerous commands without clear local consent and confirmation.
