# Companion implementation checklist

A companion is a separate app/service for the target OS. It must:
1. Generate/store its own device ID and a unique device credential.
2. Connect to the deployed WSS relay and authenticate securely.
3. Register with `register_device`.
4. Display each `pairing_request` locally and require an explicit owner decision.
5. Send `pairing_decision` only after the owner's action.
6. Accept `relay` messages only from an approved session.
7. Validate every command against a strict allowlist and platform capability.
8. Return supported status through `device_response`.
9. Provide a visible connected indicator and a one-tap disconnect/revoke control.

Platform notes:
- Windows: a signed companion service/app can implement permitted input and system APIs with clear user consent.
- Android: use user-visible foreground operation and Android accessibility/input restrictions; do not hide operation.
- iOS/iPadOS: support only permitted workflows and APIs; no unrestricted remote control of the device.
