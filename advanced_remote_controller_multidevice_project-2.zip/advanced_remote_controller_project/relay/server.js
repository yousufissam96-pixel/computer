require("dotenv").config();
const http = require("http");
const crypto = require("crypto");
const WebSocket = require("ws");

const PORT = Number(process.env.PORT || 8080);
const COMPANION_SECRET = process.env.COMPANION_SHARED_SECRET || "";
const allowedOrigins = (process.env.ALLOWED_ORIGINS || "")
  .split(",").map(x => x.trim()).filter(Boolean);

if (COMPANION_SECRET.length < 32) {
  console.error("Set COMPANION_SHARED_SECRET to a random secret of at least 32 characters.");
  process.exit(1);
}

const devices = new Map(); // deviceId -> { ws, platform, connectedAt }
const sessions = new Map(); // client deviceId -> { targetId, token, approved }
const tokens = new Map(); // token -> { clientId, targetId }
const rate = new Map();

function validId(v) { return typeof v === "string" && /^\d{8}$/.test(v); }
function send(ws, obj) {
  if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}
function randomToken() { return crypto.randomBytes(32).toString("base64url"); }
function allowedOrigin(origin) {
  if (!allowedOrigins.length) return true;
  return !!origin && allowedOrigins.includes(origin);
}
function limited(ip) {
  const now = Date.now(), item = rate.get(ip) || { n: 0, at: now };
  if (now - item.at > 60_000) { item.n = 0; item.at = now; }
  item.n++;
  rate.set(ip, item);
  return item.n <= 90;
}

const server = http.createServer((req, res) => {
  if (req.url === "/health") {
    res.writeHead(200, { "content-type": "application/json" });
    return res.end(JSON.stringify({ ok: true, service: "arc-relay", devicesOnline: devices.size }));
  }
  res.writeHead(404); res.end("Not found");
});
const wss = new WebSocket.Server({ noServer: true, maxPayload: 64 * 1024 });

server.on("upgrade", (req, socket, head) => {
  const ip = req.socket.remoteAddress || "unknown";
  if (!limited(ip) || !allowedOrigin(req.headers.origin)) {
    socket.write("HTTP/1.1 403 Forbidden\r\n\r\n"); return socket.destroy();
  }
  wss.handleUpgrade(req, socket, head, ws => wss.emit("connection", ws, req));
});

wss.on("connection", (ws, req) => {
  ws.role = null;
  ws.deviceId = null;
  ws.isAlive = true;
  ws.on("pong", () => { ws.isAlive = true; });

  ws.on("message", raw => {
    let m;
    try { m = JSON.parse(raw.toString()); } catch { return send(ws, {type:"error", message:"Invalid JSON"}); }
    if (!m || typeof m.type !== "string") return;

    // Companion registration: companions authenticate with a shared secret.
    if (m.type === "register_device") {
      if (m.secret !== COMPANION_SECRET || !validId(m.device_id)) {
        return send(ws, {type:"error", message:"Companion authentication failed"});
      }
      if (devices.has(m.device_id) && devices.get(m.device_id).ws !== ws) {
        send(devices.get(m.device_id).ws, {type:"notice", message:"A newer session replaced this connection"});
        try { devices.get(m.device_id).ws.close(); } catch {}
      }
      ws.role = "device";
      ws.deviceId = m.device_id;
      devices.set(m.device_id, { ws, platform: String(m.platform || "unknown").slice(0,30), connectedAt: Date.now() });
      return send(ws, {type:"registered", ok:true, device_id:m.device_id});
    }

    // Browser/client asks to connect to a device by ID.
    if (m.type === "connect_by_id") {
      if (!validId(m.device_id) || !validId(m.target_id || m.pc_id)) {
        return send(ws, {type:"error", message:"Invalid device ID"});
      }
      const targetId = m.target_id || m.pc_id;
      const target = devices.get(targetId);
      if (!target || target.ws.readyState !== WebSocket.OPEN) {
        return send(ws, {type:"error", message:"Target device is offline or has no companion connected"});
      }
      ws.role = "client";
      ws.deviceId = m.device_id;
      const existing = m.mode === "reconnect" && typeof m.trust_token === "string"
        ? tokens.get(m.trust_token) : null;
      if (existing && existing.clientId === m.device_id && existing.targetId === targetId) {
        sessions.set(m.device_id, {targetId, token:m.trust_token, approved:true});
        send(target.ws, {type:"client_reconnect", client_id:m.device_id});
        return send(ws, {type:"connected", ok:true});
      }
      sessions.set(m.device_id, {targetId, approved:false});
      send(target.ws, {type:"pairing_request", client_id:m.device_id, client_platform:String(m.client || "web").slice(0,30)});
      return send(ws, {type:"pairing_required", ok:false, message:"Waiting for approval on target device"});
    }

    // Target companion must explicitly approve first pairing.
    if (m.type === "pairing_decision" && ws.role === "device" && ws.deviceId) {
      const clientId = m.client_id;
      const session = sessions.get(clientId);
      if (!session || session.targetId !== ws.deviceId) return;
      const client = [...wss.clients].find(c => c.role === "client" && c.deviceId === clientId);
      if (m.approve !== true) {
        sessions.delete(clientId);
        send(client, {type:"error", message:"Pairing was declined by the target device"});
        return send(ws, {type:"pairing_result", client_id:clientId, approved:false});
      }
      const token = randomToken();
      session.approved = true;
      session.token = token;
      tokens.set(token, {clientId, targetId:ws.deviceId});
      send(client, {type:"paired", ok:true, trust_token:token});
      send(ws, {type:"pairing_result", client_id:clientId, approved:true});
      return;
    }

    // Only authenticated paired sessions may relay commands/data.
    if (ws.role === "client" && ws.deviceId) {
      const s = sessions.get(ws.deviceId);
      if (!s || !s.approved) return send(ws, {type:"error", message:"Pairing not approved"});
      const target = devices.get(s.targetId);
      if (!target || target.ws.readyState !== WebSocket.OPEN) return send(ws, {type:"error", message:"Target device disconnected"});
      // Prevent clients from forging relay control messages.
      if (["register_device","connect_by_id","pairing_decision"].includes(m.type)) return;
      send(target.ws, {type:"relay", client_id:ws.deviceId, payload:m});
      return;
    }
    if (ws.role === "device" && ws.deviceId) {
      if (m.type === "device_response" && validId(m.client_id)) {
        const client = [...wss.clients].find(c => c.role === "client" && c.deviceId === m.client_id);
        if (client) send(client, m.payload);
      }
    }
  });

  ws.on("close", () => {
    if (ws.role === "device" && devices.get(ws.deviceId)?.ws === ws) devices.delete(ws.deviceId);
    if (ws.role === "client") sessions.delete(ws.deviceId);
  });
});

const heartbeat = setInterval(() => {
  for (const ws of wss.clients) {
    if (!ws.isAlive) { ws.terminate(); continue; }
    ws.isAlive = false; ws.ping();
  }
}, 30000);
wss.on("close", () => clearInterval(heartbeat));

server.listen(PORT, "0.0.0.0", () => {
  console.log(`ARC relay listening on port ${PORT}`);
  console.log("Use HTTPS/WSS through a TLS reverse proxy before exposing this service publicly.");
});
