انسخ config.example.js إلى config.js بعد نشر خادم Relay، ثم ضع عنوان WSS الحقيقي. لا تستخدم عنوان المثال كما هو.
