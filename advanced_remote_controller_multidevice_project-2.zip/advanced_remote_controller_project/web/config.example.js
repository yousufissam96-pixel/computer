// انسخ هذا الملف إلى config.js وضع عنوان خادم Relay المنشور لديك.
// مثال فقط: wss://relay.example.com (ليس عنوانًا حقيقيًا جاهزًا)
window.REMOTE_DEVICE_SERVER = 'wss://YOUR-RELAY-DOMAIN';
